def my_func_1():
    # [MYIU-AUTO-FIX] a=1 # Unused variable
    print(
        "This is a very long line that will definitely exceed the standard limit of characters allowed in a single line of python code by the pep8 style guide."  # TODO: Refactor long line  # TODO: Refactor long line
    )  # TODO: Refactor long line


def my_func_2():
    pass
