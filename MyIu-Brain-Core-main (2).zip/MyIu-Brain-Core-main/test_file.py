import os\nimport sys\ndef my_func():\n    x=1
