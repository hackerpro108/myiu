def my_test_function():
    print("This is a test function.")
    # The next line has an unused variable
    # [MYIU-AUTO-FIX] unused_var = "this should be flagged by the analyzer" # TODO: Review F841 - Unused variable  # TODO: Refactor long line  # TODO: Refactor long line
    print("Function finished.")
