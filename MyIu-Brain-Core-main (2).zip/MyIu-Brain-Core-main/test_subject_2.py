def another_test():
    # [MYIU-AUTO-FIX] result = "ok" # F841: local variable 'result' is assigned to but never used # Unused variable  # TODO: Refactor long line
    print("This is another test.")
